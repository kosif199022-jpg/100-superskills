---
name: ultra-motion-montage
description: "Ultra-High Graphic Animation & Intelligent Video Montage Studio (استوديو الأنيميشن فائق الجرافيك والمونتاج الذكي). Creates Hollywood & Awwwards-grade 3D WebGL (Three.js PBR, volumetric lighting) and 2D kinetic animations (GSAP, Arabic RTL typography, spring physics), renders deterministic 60fps/30fps MP4s via hardware Edge D3D11 GPU capture, and autonomously edits ANY raw video footage with beat-synced cuts, dynamic retention zoom punches, B-roll insertion, TikTok/Reels kinetic karaoke subtitles, sidechain music ducking (-18 dB), studio color grading (Teal & Orange, Cyberpunk, Golden Hour), and EBU R128 (-14 LUFS) broadcast mastering. Synthesized from 15,000 skills in KOSIF Atlas. Triggers on: 'انميشن', 'أنيميشن', 'مونتاج', 'فيديو', 'موشن غرافيك', 'موشن', 'قص فيديو', 'ترجمة فيديو', 'سبتايتل', 'تلوين فيديو', 'مونتاج ذكي', 'انميشن فائق', 'threejs', 'ffmpeg', 'animation', 'video montage', 'smart montage', 'motion graphics', 'auto edit', 'color grading', 'kinetic captions'."
metadata:
  superskill: 115
  title_ar: استوديو الأنيميشن فائق الجرافيك والمونتاج الذكي
  version: 2.0.0
---

# استوديو الأنيميشن فائق الجرافيك والمونتاج الذكي — Ultra Motion & Montage Studio

استوديو ثوري متكامل يعمل على **Google Antigravity** و**Claude** (Claude Code, Desktop, claude.ai, KOSIF Omni)، يجمع بين قوة **الأنيميشن الإجرائي فائق الجرافيك** (2D/3D) و**المونتاج الذكي التلقائي لأي فيديو**، معتمداً على أدوات النظام الحتمية المدمجة (Python, FFmpeg, Playwright/Edge D3D11 GPU) وخلاصة 15 ألف مهارة من مكتبة **KOSIF Atlas**.

---

## ⚡ متى تُستخدم هذه المهارة (Triggers)
- **بالعربية:** أنيميشن، انميشن، مونتاج، فيديو، موشن غرافيك، موشن، قص فيديو، تعديل فيديو، ترجمة فيديو، سبتايتل، تلوين فيديو، مونتاج ذكي، انميشن فائق، اصنع فيديو، ريلز متحرك، برومبت سينمائي.
- **بالإنجليزية:** animation, motion graphics, video montage, smart montage, auto edit, video editing, kinetic typography, subtitles, color grading, beat cut, threejs animation, ffmpeg pipeline.

---

## 🏗️ البنية والقدرات الفائقة

### 1. محرك الأنيميشن فائق الجرافيك (Ultra-Graphic Engine)
- **ثلاثي الأبعاد (3D WebGL Cinema):** مشاهد Three.js سينمائية بإضاءة فيزيائية ثلاثية النقاط (Key, Fill, Rim Light)، ومواد PBR فائقة الواقعية، وضباب حجمي، وأنظمة جزيئات مشعة، وكاميرا سينمائية متحركة.
- **ثنائي الأبعاد (2D Kinetic Typography & Motion):** تايبوغرافي عربية متطورة بنظام أقنعة الكلمات المنفصلة (Word Masks)، وحركة نوابض فيزيائية (Spring Dynamics)، وموجات لونية تفاعلية.
- **الزمن الحتمي `render(t)`:** خلو كامل من التقطيع وتذبذب الإطارات؛ المشهد دالة نقية في الزمن تتطابق فيه المعاينة مع الفيديو النهائي بنسبة 100%.
- **التصوير المسرع عتادياً (Hardware GPU Capture):** التقاط الإطارات بدقة كاملة (1080×1920 أو 4K) عبر متصفح Microsoft Edge مع تسريع Direct3D 11 الحقيقي لكارت الشاشة.

### 2. محرك المونتاج الذكي لأي فيديو (Intelligent Video Montage)
- **القص التلقائي على النبض الموسيقي (Beat-Matched Cuts):** تحليل الترددات والنبضات الموسيقية (BPM) واكتشاف لحظات الذروة (Transients) بدقة ملليمترية، ومزامنة الانتقالات البصرية على الضربة الأولى (`60 / BPM`).
- **الزووم النبضي لرفع الاحتفاظ (Dynamic Retention Zoom Punches):** الانتقال التبادلي بين زاوية 1.0x وزاوية 1.10x–1.12x كل بضع ثوانٍ لمنع التشتت والملل البصري في فيديوهات الشرح والمتحدثين.
- **تراكب الـ B-Roll والمؤثرات:** إدراج لقطات داعمة أو مشاهد أنيميشن ثلاثية الأبعاد بسلاسة في الفجوات الزمنية.
- **الترجمة الحركية الذكية (Kinetic Subtitles):** توليد ترجمة بأسلوب كاريوكي الفيديوهات الرائجة (Reels / TikTok) تضيء الكلمة المنطوقة، مع دعم كامل للغة العربية (RTL) وحد خارجي وظلال لمنع تداخل النص مع الخلفية.
- **التلوين السينمائي (Color Grading):** 6 قوالب سينمائية جاهزة عبر FFmpeg:
  - `teal_orange` (التباين السينمائي الهوليوودي)
  - `golden_hour` (دفء الغروب الذهبي)
  - `cyberpunk` (نيون خيال علمي فاقع)
  - `vintage_film` (محاكاة فيلم كوداك التناظري)
  - `matrix_tech` (الظلال الزمردية التقنية)
  - `clean_commercial` (ألوان نقية فائقة الوضوح للإعلانات)
- **هندسة الصوت والتخفيض التلقائي (Audio Sidechain Ducking):**
  - خفض صوت الموسيقى تلقائياً بمقدار `-18 dB` عند وجود كلام أو تعليق صوتي.
  - معايرة الصوت وفق المعيار العالمي EBU R128 بمستوى `-14.0 LUFS` وذروة `-1.0 dBTP`.
- **مخرج برومبتات الفيديو للذكاء الاصطناعي (AI Diffusion Prompts):** صياغة برومبتات متزامنة لكل لقطة لنماذج Veo 2 وSora وKling وRunway بالتشريح السباعي (7-Layer Anatomy).

---

## 🛠️ خط الإنتاج والأوامر الجاهزة (CLI Suite)

المهارة مزودة بأدوات تنفيذية حتمية في مجلد `scripts/` تعمل مباشرة عبر Python:

### أولاً: صناعة الأنيميشن
```bash
# 1. إنشاء مشروع أنيميشن جديد (3D أو 2D)
python scripts/ultra_animator.py new my_film --type 3d --ratio 9:16 --seconds 10 --title "مستقبل الذكاء الاصطناعي"

# 2. تصوير الإطارات بدقة كاملة عبر كارت الشاشة Direct3D 11
python scripts/ultra_animator.py capture my_film --fps 30

# 3. تجميع الفيديو إلى MP4 عالي الجودة مع لوحة التحقق
python scripts/ultra_animator.py encode my_film --fps 30 --crf 17
```

### ثانياً: المونتاج الذكي لأي فيديو
```bash
# 1. تحليل النبض الموسيقي (BPM) وحساب أزمنة القص
python scripts/beat_detector.py music.mp3

# 2. مونتاج تلقائي ذكي (قص على الإيقاع + زووم نبضي + تلوين سينمائي + دمج الصوت وموازنته)
python scripts/smart_montage.py auto raw_video.mp4 --music soundtrack.mp3 --preset teal_orange --out edited_final.mp4

# 3. حرق ترجمة حركية كاريوكي على الفيديو
python scripts/smart_montage.py captions edited_final.mp4 --spec captions.json --style tiktok

# 4. تطبيق تلوين سينمائي مخصص
python scripts/smart_montage.py grade my_video.mp4 --preset golden_hour
```

### ثالثاً: فحص الجودة الشامل (QA Gatekeeper)
```bash
python scripts/qa_inspector.py edited_final.mp4
# يفحص الإطارات المتجمدة، والشاشات السوداء، ومستوى الصوت (-14 LUFS)، ويولّد لوحة الفحص contact-sheet.png
```

---

## 🏆 بوابات الجودة (Quality Gates)
1. **لا تسليم قبل التحقق البصري:** فحص `contact-sheet.png` للتأكد من خلو الفيديو من أي عيوب أو شاشات سوداء.
2. **الصوت مقاس لا مقدر:** يجب أن يمر الصوت بفحص `ebur128` محققاً نطاق `-14 ± 1.5 LUFS`.
3. **النصوص مقروءة 100%:** لا يقل تباين الترجمة عن `4.5:1`، والخطوط العربية مضبوطة في مسارها الآمن بعيداً عن أزرار المنصات.
4. **التوافق التام:** الفيديو النهائي بترميز H.264 وyuv420p ليعمل بسلاسة على كافة الهواتف والمنصات.
